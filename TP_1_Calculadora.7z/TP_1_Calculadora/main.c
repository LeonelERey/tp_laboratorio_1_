#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

int main()
{
    char seguir='s';
    int opcion=0;
    float num1;
    float num2;
    long long int respuesta;
    float respuestaComa;
    int flag=0;
    int flag2=0;
    float aux;
    float aux2;

    while(seguir=='s')
    {
        system("color F");
        opcion=opciones(num1,num2,flag,flag2);

        switch(opcion)
        {
        case 1:
            system("color B");
            num1=preguntar("ingrese el primer numero:");
            flag=1;
            system("pause");
            system("cls");

            break;
        case 2:
            system("color B");
            num2=preguntar("ingrese el segundo numero:");
            flag2=1;
            system("pause");
            system("cls");

            break;
        case 3:
            if(flag==1&&flag2==1)
            {
                respuestaComa=sumar(num1,num2);
                system("color A");
                printf("la sumatoria de los numeros es: %f\n",respuestaComa);
                system("pause");
                system("cls");
                break;

            }
            else
            {
                system("color C");
                printf("no a ingresado alguno de los numeros!!\n");
                system("pause");
                system("cls");
                break;
            }
        case 4:
            if(flag==1&&flag2==1)
            {
                respuesta=restar(num1,num2);
                system("color A");
                printf("la resta de los numeros es: %f\n",respuesta);
                system("pause");
                system("cls");
                break;
            }
            else
            {
                system("color C");
                printf("no a ingresado alguno de los numeros!!\n");
                system("pause");
                system("cls");
                break;
            }

        case 5:
            if(flag==1&&flag2==1)
            {
                if(num2!=0)
                {
                    respuestaComa=dividir(num1,num2);
                    system("color A");
                    printf("la divicion de los numeros es: %.2f\n",respuestaComa);
                }
                else
                {
                    system("color C");
                    num2=preguntar("no se puede realizar la operacion con 0!!\ningrese otro numero:");
                }
                system("pause");
                system("cls");
                break;
            }
            else
            {
                system("color C");
                printf("no a ingresado alguno de los numeros!!\n");
                system("pause");
                system("cls");
                break;
            }
        case 6:
            if(flag==1&&flag2==1)
            {
                respuesta=multiplicar(num1,num2);
                system("color A");
                printf("la multiplicacion de los numeros es: %f\n",respuesta);
                system("pause");
                system("cls");
                break;
            }
            else
            {
                system("color C");
                printf("no a ingresado alguno de los numeros!!\n");
                system("pause");
                system("cls");
                break;
            }
        case 7:
            aux=num1;
            aux2=(int)aux-num1;
            if(aux2==0)
            {
                if(flag==1)
                {
                    respuesta=factorial(num1);
                    system("color A");
                    printf("el factorial del numero es: %d\n",respuesta);
                    system("pause");
                    system("cls");
                    break;
                }
                else
                {
                    system("color C");
                    printf("no a ingresado el primer numeros!!\n");
                    system("pause");
                    system("cls");
                    break;
                }
            }
            else
            {
                system("color C");
                printf("no se puede realizar esta operacion con un numero con coma.\n");
            }
            system("pause");
            system("cls");
            break;
        case 8:
            if(flag==1&&flag2==1)
            {
                respuestaComa=sumar(num1,num2);
                system("color D");
                printf("la sumatoria de los numeros es: %f\n",respuestaComa);
                respuestaComa=restar(num1,num2);
                printf("la resta de los numeros es: %f\n",respuestaComa);
                respuestaComa=dividir(num1,num2);
                printf("la divicion de los numeros es: %.2f\n",respuestaComa);
                respuestaComa=multiplicar(num1,num2);
                printf("la multiplicacion de los numeros es: %f\n",respuestaComa);
                respuesta=factorial(num1);
                printf("el factorial del numero es: %d\n",respuesta);
                system("pause");
                system("cls");
                break;
            }
            else
            {
                system("color C");
                printf("no a ingresado alguno de los numeros!!\n");
                system("pause");
                system("cls");
                break;
            }
        case 9:
            seguir = 'n';
            break;
        }
    }


    return 0;
}
