#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
float sumar (float,float);
float restar (float,float);
float dividir (float,float);
float multiplicar(float,float);
long long int factorial(int);
float preguntar (char titulo[]);
int opciones (float,float,int,int);
int validarnum1 (int);


#endif // FUNCIONES_H_INCLUDED
