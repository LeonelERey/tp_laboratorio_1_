#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"
int opciones (float num1,float num2,int flag,int flag1)
{
    int opcion;
    if(flag!=1&&flag!=1)
    {
        printf("1- Ingresar 1er operando (A=x)\n");
        printf("2- Ingresar 2do operando (B=y)\n");
        printf("3- Calcular la suma (A+B)\n");
        printf("4- Calcular la resta (A-B)\n");
        printf("5- Calcular la division (A/B)\n");
        printf("6- Calcular la multiplicacion (A*B)\n");
        printf("7- Calcular el factorial (A!)\n");
        printf("8- Calcular todas las operacione\n");
        printf("9- Salir\n");
        scanf("%d",&opcion);
        flag=1;
    }
    else
    {
        if(flag==1&&flag1==1)
        {
            printf("1- Ingresar 1er operando (A=%f)\n",num1);
            printf("2- Ingresar 2do operando (B=%f)\n",num2);
            printf("3- Calcular la suma (A+B)\n");
            printf("4- Calcular la resta (A-B)\n");
            printf("5- Calcular la division (A/B)\n");
            printf("6- Calcular la multiplicacion (A*B)\n");
            printf("7- Calcular el factorial (A!)\n");
            printf("8- Calcular todas las operacione\n");
            printf("9- Salir\n");
            scanf("%d",&opcion);
        }
        else
        {
            printf("1- Ingresar 1er operando (A=%f)\n",num1);
            printf("2- Ingresar 2do operando (B=y)\n");
            printf("3- Calcular la suma (A+B)\n");
            printf("4- Calcular la resta (A-B)\n");
            printf("5- Calcular la division (A/B)\n");
            printf("6- Calcular la multiplicacion (A*B)\n");
            printf("7- Calcular el factorial (A!)\n");
            printf("8- Calcular todas las operacione\n");
            printf("9- Salir\n");
            scanf("%d",&opcion);
            flag1=1;
        }
    }
    return opcion;

}
int validarnum1 (int flag)
{
    int num1;
    if(flag==0)
    {
        num1=preguntar("no se puede realicar la opercion si no a ingresado un numero antes:");
    }

}
float preguntar (char titulo[])
{
    float dato;

    printf("%s", titulo);
    scanf("%f", &dato);

    return dato;
}
float sumar (float num1,float num2)
{
    float resultado;

    resultado=num1+num2;

    return resultado;
}
float restar (float num1,float num2)
{
    float resultado;

    resultado=num1-num2;

    return resultado;
}
float dividir (float num1,float num2)
{
    float respuesta;

    respuesta=num1/num2;


    return respuesta;
}
float multiplicar(float num1,float num2)
{
    float resultado;

    resultado=num1*num2;

    return resultado;
}
long long int factorial(int num1)
{

    long long int resultado;

    if(num1==0)
    {
        return 1;
    }
    else
    {
        resultado=num1*factorial(num1-1);
        return (resultado);
    }
}



